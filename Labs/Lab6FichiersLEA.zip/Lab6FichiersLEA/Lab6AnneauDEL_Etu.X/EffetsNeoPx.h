#ifndef EFFETSNEOPXL_H
#define EFFETSNEOPXL_H


/********** prototypes *****************/
void NeoRotate(void);
void NeoWave(void);

#endif